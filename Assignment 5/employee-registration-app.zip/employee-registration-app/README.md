# Employee Registration App

This is a simple JSP, Servlet and JDBC project for an employee registration assignment.

## Files to use in IntelliJ

- `src/main/java/com/example/employeeregistration/model/Employee.java`
- `src/main/java/com/example/employeeregistration/util/DBConnection.java`
- `src/main/java/com/example/employeeregistration/dao/EmployeeDAO.java`
- `src/main/java/com/example/employeeregistration/servlet/EmployeeRegistrationServlet.java`
- `src/main/webapp/index.jsp`
- `src/main/webapp/success.jsp`
- `src/main/webapp/WEB-INF/web.xml`
- `database.sql`

## Before running

1. Create the database with `database.sql`.
2. Update the MySQL username and password in `DBConnection.java`.
3. Import the folder as a Maven project in IntelliJ.
4. Configure Apache Tomcat in IntelliJ and deploy the WAR.
