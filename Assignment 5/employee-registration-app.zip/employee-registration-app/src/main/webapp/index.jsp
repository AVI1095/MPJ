<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Employee Registration</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: #f4f7fb;
            margin: 0;
            padding: 32px;
        }
        .container {
            max-width: 640px;
            margin: 0 auto;
            background: #ffffff;
            padding: 28px;
            border-radius: 14px;
            box-shadow: 0 10px 24px rgba(0, 0, 0, 0.08);
        }
        h1 {
            margin-top: 0;
            color: #1d3557;
        }
        .error {
            background: #ffe5e5;
            color: #b42318;
            padding: 12px;
            border-radius: 8px;
            margin-bottom: 16px;
        }
        .field {
            margin-bottom: 16px;
        }
        label {
            display: block;
            margin-bottom: 6px;
            font-weight: bold;
        }
        input {
            width: 100%;
            padding: 10px 12px;
            border: 1px solid #c9d3e0;
            border-radius: 8px;
            box-sizing: border-box;
        }
        button {
            background: #1d3557;
            color: #ffffff;
            border: none;
            padding: 12px 18px;
            border-radius: 8px;
            cursor: pointer;
        }
        button:hover {
            background: #16304d;
        }
    </style>
</head>
<body>
<div class="container">
    <h1>Employee Registration Form</h1>

    <c:if test="${not empty errorMessage}">
        <div class="error">${errorMessage}</div>
    </c:if>

    <form action="${pageContext.request.contextPath}/registerEmployee" method="post">
        <div class="field">
            <label for="fullName">Full Name</label>
            <input id="fullName" name="fullName" type="text" value="${param.fullName}" required>
        </div>

        <div class="field">
            <label for="email">Email</label>
            <input id="email" name="email" type="email" value="${param.email}" required>
        </div>

        <div class="field">
            <label for="department">Department</label>
            <input id="department" name="department" type="text" value="${param.department}" required>
        </div>

        <div class="field">
            <label for="designation">Designation</label>
            <input id="designation" name="designation" type="text" value="${param.designation}" required>
        </div>

        <div class="field">
            <label for="salary">Salary</label>
            <input id="salary" name="salary" type="number" min="0.01" step="0.01" value="${param.salary}" required>
        </div>

        <button type="submit">Register Employee</button>
    </form>
</div>
</body>
</html>
