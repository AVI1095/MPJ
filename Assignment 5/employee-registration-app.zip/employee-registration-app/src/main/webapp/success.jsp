<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registration Success</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: #eef8f1;
            margin: 0;
            padding: 32px;
        }
        .card {
            max-width: 640px;
            margin: 0 auto;
            background: #ffffff;
            padding: 28px;
            border-radius: 14px;
            box-shadow: 0 10px 24px rgba(0, 0, 0, 0.08);
        }
        h1 {
            color: #166534;
            margin-top: 0;
        }
        .row {
            margin-bottom: 10px;
        }
        .label {
            font-weight: bold;
        }
        a {
            display: inline-block;
            margin-top: 16px;
            color: #1d4ed8;
            text-decoration: none;
        }
    </style>
</head>
<body>
<div class="card">
    <h1>Employee Registered Successfully</h1>

    <div class="row"><span class="label">Employee ID:</span> <c:out value="${employee.id}"/></div>
    <div class="row"><span class="label">Full Name:</span> <c:out value="${employee.fullName}"/></div>
    <div class="row"><span class="label">Email:</span> <c:out value="${employee.email}"/></div>
    <div class="row"><span class="label">Department:</span> <c:out value="${employee.department}"/></div>
    <div class="row"><span class="label">Designation:</span> <c:out value="${employee.designation}"/></div>
    <div class="row"><span class="label">Salary:</span> <c:out value="${employee.salary}"/></div>

    <a href="${pageContext.request.contextPath}/index.jsp">Register another employee</a>
</div>
</body>
</html>
