package com.example.employeeregistration.dao;

import com.example.employeeregistration.model.Employee;
import com.example.employeeregistration.util.DBConnection;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class EmployeeDAO {
    private static final String INSERT_EMPLOYEE_SQL =
            "INSERT INTO employees (full_name, email, department, designation, salary) VALUES (?, ?, ?, ?, ?)";

    public int registerEmployee(Employee employee) throws SQLException {
        try (Connection connection = DBConnection.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(
                     INSERT_EMPLOYEE_SQL,
                     Statement.RETURN_GENERATED_KEYS
             )) {
            preparedStatement.setString(1, employee.getFullName());
            preparedStatement.setString(2, employee.getEmail());
            preparedStatement.setString(3, employee.getDepartment());
            preparedStatement.setString(4, employee.getDesignation());
            preparedStatement.setBigDecimal(5, employee.getSalary());

            int rowsInserted = preparedStatement.executeUpdate();
            if (rowsInserted == 0) {
                return 0;
            }

            try (ResultSet generatedKeys = preparedStatement.getGeneratedKeys()) {
                if (generatedKeys.next()) {
                    return generatedKeys.getInt(1);
                }
            }
        }
        return 0;
    }
}
