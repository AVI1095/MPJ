package com.example.employeeregistration.servlet;

import com.example.employeeregistration.dao.EmployeeDAO;
import com.example.employeeregistration.model.Employee;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.math.BigDecimal;
import java.sql.SQLException;

public class EmployeeRegistrationServlet extends HttpServlet {
    private final EmployeeDAO employeeDAO = new EmployeeDAO();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        request.getRequestDispatcher("/index.jsp").forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");

        String fullName = clean(request.getParameter("fullName"));
        String email = clean(request.getParameter("email"));
        String department = clean(request.getParameter("department"));
        String designation = clean(request.getParameter("designation"));
        String salaryText = clean(request.getParameter("salary"));

        if (fullName.isEmpty() || email.isEmpty() || department.isEmpty() || designation.isEmpty() || salaryText.isEmpty()) {
            request.setAttribute("errorMessage", "All fields are required.");
            request.getRequestDispatcher("/index.jsp").forward(request, response);
            return;
        }

        BigDecimal salary;
        try {
            salary = new BigDecimal(salaryText);
            if (salary.compareTo(BigDecimal.ZERO) <= 0) {
                request.setAttribute("errorMessage", "Salary must be greater than 0.");
                request.getRequestDispatcher("/index.jsp").forward(request, response);
                return;
            }
        } catch (NumberFormatException exception) {
            request.setAttribute("errorMessage", "Enter a valid salary amount.");
            request.getRequestDispatcher("/index.jsp").forward(request, response);
            return;
        }

        Employee employee = new Employee();
        employee.setFullName(fullName);
        employee.setEmail(email);
        employee.setDepartment(department);
        employee.setDesignation(designation);
        employee.setSalary(salary);

        try {
            int generatedId = employeeDAO.registerEmployee(employee);
            if (generatedId > 0) {
                employee.setId(generatedId);
                request.setAttribute("employee", employee);
                request.getRequestDispatcher("/success.jsp").forward(request, response);
                return;
            }

            request.setAttribute("errorMessage", "Employee registration failed. Please try again.");
            request.getRequestDispatcher("/index.jsp").forward(request, response);
        } catch (SQLException exception) {
            request.setAttribute("errorMessage", "Database error: " + exception.getMessage());
            request.getRequestDispatcher("/index.jsp").forward(request, response);
        }
    }

    private String clean(String value) {
        return value == null ? "" : value.trim();
    }
}
